# sample-lib v1.0.0

A sample library for demonstration purposes
