# web-framework v0.9.5

Lightweight web framework for applications
